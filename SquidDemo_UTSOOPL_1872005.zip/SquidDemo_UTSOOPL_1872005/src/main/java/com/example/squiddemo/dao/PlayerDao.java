package com.example.squiddemo.dao;

import com.example.squiddemo.entitas.Player;
import com.example.squiddemo.util.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**Michael Sebastian Gunadi-1872005*/

public class PlayerDao implements DaoInterface<Player>{
    @Override
    public List<Player> fetchAll() throws SQLException, ClassNotFoundException {
        List<Player> players = new ArrayList<>();
        try (Connection connection = MySQLConnection.createConnection()){
            String query = "SELECT id,Nama,Umur,Keahlian FROM Player";
            try(PreparedStatement ps = connection.prepareStatement(query)){
                try (ResultSet rs = ps.executeQuery()){
                    while (rs.next()){
                        Player player = new Player();
                        player.setId(rs.getInt("id"));
                        player.setNama(rs.getString("Nama"));
                        player.setUmur(rs.getInt("Umur"));
                        player.setKeahlian(rs.getString("Keahlian"));
                        players.add(player);
                    }
                }
            }
        }
        return players;
    }

    @Override
    public int addData(Player object) throws SQLException, ClassNotFoundException {
        int result = 0;
        Connection connection = MySQLConnection.createConnection();
        String query = "INSERT INTO Player(Nama,Umur,Keahlian) VALUES(?,?,?)";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1,object.getNama());
        ps.setInt(2,object.getUmur());
        ps.setString(3,object.getKeahlian());
        if (ps.executeUpdate() != 0){
            connection.commit();
            result = 1;
        }else {
            connection.rollback();
        }
        ps.close();
        connection.close();
        return result;
    }

    @Override
    public int updateData(Player object) throws SQLException, ClassNotFoundException {
        int result = 0;
        Connection connection = MySQLConnection.createConnection();
        String query = "UPDATE INTO Player (Nama,Umur,Keahlian) VALUES (?,?,?)WHERE id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1,object.getNama());
        ps.setInt(2,object.getUmur());
        ps.setString(3,object.getKeahlian());
        ps.setInt(4,object.getId());
        if (ps.executeUpdate() != 0){
            connection.commit();
            result = 1;
        } else{
            connection.rollback();
        }
        ps.close();
        connection.close();
        return result;
    }

    @Override
    public int deleteData(Player object) throws SQLException, ClassNotFoundException {
        int result = 0;
        Connection connection = MySQLConnection.createConnection();
        String query = "DELETE FROM Player WHERE id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setInt(1,object.getId());
        if (ps.executeUpdate() != 0){
            connection.commit();
            result = 1;
        } else{
            connection.rollback();
        }
        ps.close();
        connection.close();
        return result;
    }
}
