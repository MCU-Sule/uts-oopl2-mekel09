package com.example.squiddemo.controller;

import com.example.squiddemo.SquidApplication;
import com.example.squiddemo.dao.HutangDao;
import com.example.squiddemo.dao.PlayerDao;
import com.example.squiddemo.entitas.Hutang;
import com.example.squiddemo.entitas.Player;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**Michael Sebastian Gunadi-1872005*/

public class SquidController implements Initializable {

    @FXML
    private TextField txtPemberiUtang;
    @FXML
    private TextField txtJumlah;
    @FXML
    private ComboBox<Player> cmbPeserta;
    @FXML
    public TableView<Player> tablePemain;
    @FXML
    private TableView<Hutang> tableHutang;
    @FXML
    private TableColumn<Player,Integer> colId;
    @FXML
    private TableColumn<Player, String> colNama;
    @FXML
    private TableColumn<Player, Integer> colUmur;
    @FXML
    private TableColumn<Player,String> colKemampuan;
    @FXML
    private TableColumn<Hutang, Integer> colIdPemain;
    @FXML
    private TableColumn<Hutang, String> colHutang;
    @FXML
    private TableColumn<Hutang,Double> colJumlah;

    private ObservableList<Player> plist;

    private ObservableList<Hutang> hlist;

    private PlayerDao playerDao;

    private HutangDao hutangDao;

    public Player update_player;


    public Player getSelectedRow(){
        return this.update_player =(Player) tablePemain.getSelectionModel().getSelectedItem();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        playerDao = new PlayerDao();
        hutangDao = new HutangDao();
        hlist = FXCollections.observableArrayList();
        plist = FXCollections.observableArrayList();
        try {
            plist.addAll(playerDao.fetchAll());
            hlist.addAll(hutangDao.fetchAll());
        }catch (SQLException | ClassNotFoundException throwables){
            throwables.printStackTrace();
        }
        cmbPeserta.setItems(plist);
        cmbPeserta.getSelectionModel().select(0);
        tablePemain.setItems(plist);
        tableHutang.setItems(hlist);
        colId.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getId())));
        colNama.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNama()));
        colUmur.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getUmur())));
        colIdPemain.setCellValueFactory(data-> new SimpleStringProperty(String.valueOf(data.getValue().getIdUtang())));
        colHutang.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPemberiUtang()));
        colJumlah.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getJumlah()));
    }

    public void addPemain(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(SquidApplication.class.getResource("ModalPage.fxml"));
        Parent root = loader.load();
        StageModalController sc = loader.getController();
        Stage secondStage = new Stage();
        secondStage.setTitle("Page 2");
        secondStage.setScene(new Scene(root));
        secondStage.initModality(Modality.APPLICATION_MODAL);
        secondStage.showAndWait();

        plist.add(sc.temp);
        refreshTable();
    }

    private void refreshTable() {
        tablePemain.setItems(plist);
    }

    public void updatePemain(ActionEvent actionEvent) {
    }


    public void deletePemain(Object object) {
        Alert alert = new Alert (Alert.AlertType.CONFIRMATION);
        alert.setContentText("Yakin mau dihapus?");
        alert.showAndWait();
        if (alert.getResult() == ButtonType.OK){
            if (object instanceof Player){
                try{
                    if (playerDao.deleteData(getSelectedRow())==1){
                        plist.clear();
                        plist.addAll(playerDao.fetchAll());
                    }
                }catch (SQLException | ClassNotFoundException throwables){
                    throwables.printStackTrace();
                }
            }
        }
    }

    public void tambahUtang(ActionEvent actionEvent) {
        if (txtPemberiUtang.getText().isEmpty()||txtJumlah.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error");
            alert.setHeaderText("Tolong isi Nama Pemberi Utang dan Jumlah");
            alert.showAndWait();
        }else{
            Hutang hutang = new Hutang();
            hutang.setPemberiUtang(txtPemberiUtang.getText().trim());
            hutang.setJumlah(Double.parseDouble(txtJumlah.getText()));
            hlist.add(hutang);
        }
    }

    public void HapusUtang(Object object) {
        Alert alert = new Alert (Alert.AlertType.CONFIRMATION);
        alert.setContentText("Yakin mau dihapus?");
        alert.showAndWait();
        if (alert.getResult() == ButtonType.OK){
            if (object instanceof Hutang){
                try{
                    if (hutangDao.deleteData(getSelectedRow())==1){
                        hlist.clear();
                        hlist.addAll(hutangDao.fetchAll());
                    }
                }catch (SQLException | ClassNotFoundException throwables){
                    throwables.printStackTrace();
                }
            }
        }
    }
}
