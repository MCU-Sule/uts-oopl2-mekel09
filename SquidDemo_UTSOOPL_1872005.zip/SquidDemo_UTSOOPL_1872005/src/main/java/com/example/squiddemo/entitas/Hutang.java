package com.example.squiddemo.entitas;

/**Michael Sebastian Gunadi-1872005*/

public class Hutang {
    private int idUtang;
    private String pemberiUtang;
    private double jumlah;
    private Player player;

    public Hutang(){
        this.idUtang = idUtang;
        this.pemberiUtang = pemberiUtang;
        this.jumlah = jumlah;
        this.player = player;
    }

    public int getIdUtang() {
        return idUtang;
    }

    public void setIdUtang(int idUtang) {
        this.idUtang = idUtang;
    }

    public String getPemberiUtang() {
        return pemberiUtang;
    }

    public void setPemberiUtang(String pemberiUtang) {
        this.pemberiUtang = pemberiUtang;
    }

    public double getJumlah() {
        return jumlah;
    }

    public void setJumlah(double jumlah) {
        this.jumlah = jumlah;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }
}
