package com.example.squiddemo.dao;

import java.sql.SQLException;
import java.util.List;

/**Michael Sebastian Gunadi-1872005*/

public interface DaoInterface<T> {

    List<T> fetchAll() throws SQLException, ClassNotFoundException;

    int addData(T object) throws SQLException, ClassNotFoundException;

    int updateData(T object) throws SQLException, ClassNotFoundException;

    int deleteData(T object) throws SQLException, ClassNotFoundException;

}