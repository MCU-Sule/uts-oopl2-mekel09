package com.example.squiddemo.controller;

import com.example.squiddemo.SquidApplication;
import com.example.squiddemo.dao.PlayerDao;
import com.example.squiddemo.entitas.Player;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**Michael Sebastian Gunadi-1872005*/

public class StageModalController implements Initializable {

    @FXML
    private TextField txtId;
    @FXML
    private TextField txtNama;
    @FXML
    private TextField txtUmur;
    @FXML
    private TextField txtKeahlian;

    public ObservableList<Player> plist;

    public Player temp;

    private PlayerDao playerDao;

    private SquidController squid;


    public void initialize (URL url, ResourceBundle resourceBundle){
        playerDao = new PlayerDao();
        plist = FXCollections.observableArrayList();
    }

    public void tambah(ActionEvent actionEvent) {
        if (txtId.getText().isEmpty()||txtNama.getText().isEmpty()||txtUmur.getText().isEmpty()||txtKeahlian.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error");
            alert.setHeaderText("Tolong isi Nama , Umur , dan Keahlian");
            alert.showAndWait();
        }else{
            Player player = new Player();
            player.setId(Integer.parseInt(txtId.getText()));
            player.setNama(txtNama.getText().trim());
            player.setUmur(Integer.parseInt(txtUmur.getText()));
            player.setKeahlian(txtKeahlian.getText().trim());
            plist.add(player);
            try{
                playerDao.addData(player);
            }catch (SQLException e){
                e.printStackTrace();
            }catch (ClassNotFoundException e){
                e.printStackTrace();
            }
            ((Node) actionEvent.getSource()).getScene().getWindow().hide();
        }
    }

    public void isiTable(Player player)throws IOException{
        FXMLLoader loader = new FXMLLoader(SquidApplication.class.getResource("SquidStage.fxml"));
        Parent root = loader.load();
        SquidController sc = loader.getController();
        sc.tablePemain.setItems(plist);
    }

    public void cancel(ActionEvent actionEvent) {
        cancel(actionEvent);
    }
}
