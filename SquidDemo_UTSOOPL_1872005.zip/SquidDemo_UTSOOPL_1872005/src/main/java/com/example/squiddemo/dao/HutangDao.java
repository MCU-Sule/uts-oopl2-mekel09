package com.example.squiddemo.dao;

import com.example.squiddemo.entitas.Hutang;
import com.example.squiddemo.entitas.Player;
import com.example.squiddemo.util.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**Michael Sebastian Gunadi-1872005*/

public class HutangDao implements DaoInterface<Hutang> {
    @Override
    public List<Hutang> fetchAll() throws SQLException, ClassNotFoundException {
        List<Hutang> hutangs = new ArrayList<>();
        try (Connection connection = MySQLConnection.createConnection()) {
            String query = "SELECT h.id,h.PemberiUtang,h.Jumlah,h.Player_id,P.name AS Player_name FROM Hutang h JOIN Player p ON h.Player_id = p.id";
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Player player = new Player();
                        player.setId(rs.getInt("id"));
                        player.setNama(rs.getString("Nama"));

                        Hutang hutang = new Hutang();
                        hutang.setIdUtang(rs.getInt("id"));
                        hutang.setPemberiUtang(rs.getString("PemberiUtang"));
                        hutang.setJumlah(rs.getDouble("Jumlah"));
                        hutang.setPlayer(player);
                        hutangs.add(hutang);
                    }
                }
            }
        }
        return hutangs;
    }

    @Override
    public int addData(Hutang object) throws SQLException, ClassNotFoundException {
        int result = 0;
        Connection connection = MySQLConnection.createConnection();
        String query = "INSERT INTO Hutang (PemberiUtang,Jumlah,Player_id) VALUES (?,?,?)";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1,object.getPemberiUtang());
        ps.setDouble(2,object.getJumlah());
        ps.setString(3,object.getPlayer().getNama());
        if (ps.executeUpdate() != 0){
            connection.commit();
            result = 1;
        } else{
            connection.rollback();
        }
        ps.close();
        connection.close();
        return result;
    }

    @Override
    public int updateData(Hutang object) throws SQLException, ClassNotFoundException {
        int result = 0;
        Connection connection = MySQLConnection.createConnection();
        String query = "UPDATE INTO Hutang (PemberiUtang,Jumlah,Player_id) VALUES (?,?,?) WHERE id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1,object.getPemberiUtang());
        ps.setDouble(2,object.getJumlah());
        ps.setString(3,object.getPlayer().getNama());
        ps.setInt(4,object.getIdUtang());
        if (ps.executeUpdate() != 0){
            connection.commit();
            result = 1;
        } else{
            connection.rollback();
        }
        ps.close();
        connection.close();
        return result;
    }

    @Override
    public int deleteData(Hutang object) throws SQLException, ClassNotFoundException {
        int result = 0;
        Connection connection = MySQLConnection.createConnection();
        String query = "DELETE FROM Hutang WHERE id = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setInt(1,object.getIdUtang());
        if (ps.executeUpdate() != 0){
            connection.commit();
            result = 1;
        } else{
            connection.rollback();
        }
        ps.close();
        connection.close();
        return result;
    }
}
